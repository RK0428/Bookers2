# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end
Refile.secret_key = '4462437b9e7bde4c4e727b13a8e9b1d93f7d99fc7f4481a14246ec0e4f9f435dddef6134ff0a6f328d4d9183a0cefa952f5a6fea44f54910ce86c04f9534ad77'